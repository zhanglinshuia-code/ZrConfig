ZrConfig project development exercise (programmer tutorial)

Chinese edition: README.txt


App directories: this folder/Data, this folder/Output, this folder/Config, and this folder/Rules.
Click Generate configuration code, then Validate and export.
Expected: successful export, 0 errors, 1 warning (hero 1002 has level 95).
The final tables contain 2 Hero rows and 2 Skill rows. Hero 1001 has 2 actions; hero 1002 has 1.
Full source and instructions: repository docs/project-development.en.md, chapter 12.
This archive contains inputs only. The tool creates Generated, Serialization support source, and Output.
Do not mix these tutorial tables into the official samples/Data directory.

For everyday authoring, see docs/user-guide.en.md; the programming exercise is not a prerequisite.
The tool supplies common support source. Table authors do not need to write it; the current implementation still generates these files in the project.

Use five header rows: row 1 field names, row 2 types, row 3 primary keys, row 4 descriptions, and row 5 target side (explicit C/S/CS required; missing markers are errors). Data starts at row 6.
Both Hero and Skill mark the Id column as the primary key in row 3. Hero row 7 contains hero 1001’s second action.
Use the cell locations in docs/project-development.en.md, section 12.11, for the deliberate-error exercises.
