ZrConfig 项目开发练习包（程序员教程）
ZrConfig project development exercise (programmer tutorial)


App 四个目录：本目录/Data、本目录/Output、本目录/Config、本目录/Rules。
App directories: this folder/Data, this folder/Output, this folder/Config, and this folder/Rules.

先点击“生成配表代码”，再点击“校验并导出”。
Click “生成配表代码” (Generate configuration code), then “校验并导出” (Validate and export).

预期导出成功，错误0，警告1（英雄1002等级95的提醒）。
Expected: successful export, 0 errors, 1 warning (hero 1002 has level 95).

Hero最终2条，Skill最终2条。英雄1001有2个动作，英雄1002有1个动作。
The final tables contain 2 Hero rows and 2 Skill rows. Hero 1001 has 2 actions; hero 1002 has 1.

源码和所有操作详解在仓库 docs/project-development.md 第12章。
Full source and instructions: repository docs/project-development.md, chapter 12.

这里只包含输入文件；Generated、Serialization支持代码和Output由工具生成。
This archive contains inputs only. The tool creates Generated, Serialization support source, and Output.

不要把这些教学表混入正式 samples/Data。
Do not mix these tutorial tables into the official samples/Data directory.


日常配表使用仓库 docs/user-guide.md，无需先完成编程练习。
For everyday authoring, see docs/user-guide.md; the programming exercise is not a prerequisite.

通用支持源码由工具补齐，配表人员不需要编写。当前实现仍会在项目中生成这些文件。
The tool supplies common support source. Table authors do not need to write it; the current implementation still generates these files in the project.


表头统一为五行：第1行字段名、第2行类型、第3行主键、第4行说明，第5行所属端（明确填写 C/S/CS，缺失报错），第6行开始填数据。
Use five header rows: row 1 field names, row 2 types, row 3 primary keys, row 4 descriptions, and row 5 target side (explicit C/S/CS required; missing markers are errors). Data starts at row 6.

Hero、Skill均在第3行的Id列填写“主键”；Hero第7行是英雄1001的第二个动作。
Both Hero and Skill mark the Id column as “主键” (primary key) in row 3. Hero row 7 contains hero 1001’s second action.

改错练习按 docs/project-development.md 第12.11节的单元格位置进行。
Use the cell locations in docs/project-development.md, section 12.11, for the deliberate-error exercises.
