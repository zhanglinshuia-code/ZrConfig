ZrConfig 项目开发练习包（程序员教程）

English: README.en.txt


App 四个目录：本目录/Data、本目录/Output、本目录/Config、本目录/Rules。
先点击“生成配表代码”，再点击“校验并导出”。
预期导出成功，错误0，警告1（英雄1002等级95的提醒）。
Hero最终2条，Skill最终2条。英雄1001有2个动作，英雄1002有1个动作。
源码和所有操作详解在仓库 docs/project-development.md 第12章。
这里只包含输入文件；Generated、Serialization支持代码和Output由工具生成。
不要把这些教学表混入正式 samples/Data。

日常配表使用仓库 docs/user-guide.md，无需先完成编程练习。
通用支持源码由工具补齐，配表人员不需要编写。当前实现仍会在项目中生成这些文件。

表头统一为五行：第1行字段名、第2行类型、第3行主键、第4行说明，第5行所属端（明确填写 C/S/CS，缺失报错），第6行开始填数据。
Hero、Skill均在第3行的Id列填写“主键”；Hero第7行是英雄1001的第二个动作。
改错练习按 docs/project-development.md 第12.11节的单元格位置进行。
