using System.Collections.Generic;
using System.Linq;
using Tutorial.Config;
using ZrConfig.Models;
using ZrConfig.Validation;

[PositiveKey(nameof(HeroConfig.Id))]
[Required(nameof(HeroConfig.Name))]
[Check(nameof(HeroConfig.Name), typeof(DisplayNameRule))]
[Required(nameof(HeroConfig.Level))]
[Range(nameof(HeroConfig.Level), 1, 100)]
[Reference(nameof(HeroConfig.SkillId), typeof(SkillConfig), nameof(SkillConfig.Id),
    AllowDefaultValue = true)]
[Required(nameof(HeroConfig.Rate))]
[Check(nameof(HeroConfig.Rate), typeof(ProbabilityRule))]
[Required(nameof(HeroConfig.Enabled))]
public sealed class HeroRules : TableRules<HeroConfig>
{
    protected override void Validate(HeroConfig row, ValidationContext context)
    {
        if (!context.IsEmpty(row, nameof(HeroConfig.Level)))
        {
            if (row.Level >= 90 && row.SkillId == 0)
                context.Error(row, nameof(HeroConfig.SkillId),
                    "90 级及以上英雄必须配置技能。", "HIGH_LEVEL_SKILL");

            if (row.Level >= 95 && row.Level <= 100)
                context.Warning(row, nameof(HeroConfig.Level),
                    "等级接近上限，请确认不是误填。", "LEVEL_HIGH_NOTICE");
        }

        if (row.Enabled && context.IsEmpty(row, nameof(HeroConfig.Description)))
            context.Error(row, nameof(HeroConfig.Description),
                "启用英雄时必须填写描述。", "DESCRIPTION_REQUIRED");

        if (row.Settings.MaxTargets <= 0)
            context.Error(row, "Settings.MaxTargets",
                "最多目标数必须大于零。", "TARGET_COUNT");

        for (int i = 0; i < row.Actions.Length; i++)
        {
            BattleAction action = row.Actions[i];
            string path = $"Actions[{i}]";

            if (action.Delay < 0)
                context.Error(row, path + ".Delay",
                    "动作延时不能小于零。", "ACTION_DELAY");

            if (action is Damage damage && damage.Ratio < 0)
                context.Error(row, path + ".Ratio",
                    "伤害倍率不能小于零。", "DAMAGE_RATIO");

            if (action is AddBuff buff && buff.Stacks <= 0)
                context.Error(row, path + ".Stacks",
                    "Buff 层数必须大于零。", "BUFF_STACKS");
        }
    }

    protected override void ValidateTable(
        IReadOnlyList<HeroConfig> rows, ValidationContext context)
    {
        var groups = rows
            .Where(row => !context.IsEmpty(row, nameof(HeroConfig.Name)) &&
                          !context.IsEmpty(row, nameof(HeroConfig.Level)) &&
                          row.Level >= 1 && row.Level <= 100)
            .GroupBy(row => new
            {
                Name = row.Name.Trim().ToUpperInvariant(),
                Level = row.Level
            });

        foreach (var group in groups)
        {
            if (group.Count() <= 1) continue;
            foreach (HeroConfig row in group)
                context.Error(row, nameof(HeroConfig.Name),
                    "名称和等级的组合重复。", "NAME_LEVEL_DUPLICATE");
        }
    }
}
