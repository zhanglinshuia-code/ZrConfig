using System;
using ZrConfig.Validation;

public sealed class DisplayNameRule : IFieldRule<string>
{
    public void Validate(string value, FieldRuleContext context)
    {
        if (value.Length > 16)
            context.Error("名称不能超过 16 个字符。", "NAME_TOO_LONG");

        if (!string.Equals(value, value.Trim(), StringComparison.Ordinal))
            context.Error("名称首尾不能有空格。", "NAME_SPACE");

        foreach (char character in value)
        {
            if (!char.IsControl(character)) continue;
            context.Error("名称不能包含换行或制表符。", "NAME_CONTROL");
            break;
        }
    }
}
