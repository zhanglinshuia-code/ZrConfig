using ZrConfig.Models;
using ZrConfig.Validation;

[DependsOn(typeof(SkillConfig))]
public sealed class HeroSkillRules : TableRules<HeroConfig>
{
    protected override void Validate(HeroConfig hero, ValidationContext context)
    {
        if (context.IsEmpty(hero, nameof(HeroConfig.Level)) ||
            hero.Level < 1 || hero.Level > 100)
            return;

        // 首次访问建立索引，同一次导出的所有行和规则复用。
        var skills = context.GetSkillTable();
        if (!skills.TryGet(hero.SkillId, out var skill) || skill == null || skill.Id <= 0)
            return;

        if (context.IsEmpty(skill, nameof(SkillConfig.Damage)) || skill.Damage < 0)
            return;

        int requiredDamage = hero.Level * 5;
        if (skill.Damage < requiredDamage)
            context.Error(hero, nameof(HeroConfig.SkillId),
                $"技能 {skill.Id} 伤害为 {skill.Damage}，" +
                $"该英雄至少需要 {requiredDamage}。", "SKILL_DAMAGE_LOW");
    }
}
