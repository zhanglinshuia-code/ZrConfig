using ZrConfig.Models;
using ZrConfig.Validation;

[PositiveKey(nameof(SkillConfig.Id))]
[Required(nameof(SkillConfig.Name))]
[Check(nameof(SkillConfig.Name), typeof(DisplayNameRule))]
[Required(nameof(SkillConfig.Damage))]
[Range(nameof(SkillConfig.Damage), 0, 1000000)]
public sealed class SkillRules : TableRules<SkillConfig>
{
    protected override void Validate(SkillConfig row, ValidationContext context)
    {
        if (!context.IsEmpty(row, nameof(SkillConfig.Damage)) && row.Damage == 0)
            context.Warning(row, nameof(SkillConfig.Damage),
                "技能伤害为零，请确认是否为辅助技能。", "ZERO_DAMAGE_NOTICE");
    }
}
