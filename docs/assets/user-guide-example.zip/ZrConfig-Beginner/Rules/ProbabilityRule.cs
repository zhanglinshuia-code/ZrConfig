using ZrConfig.Validation;

public sealed class ProbabilityRule : IFieldRule<int>
{
    public void Validate(int value, FieldRuleContext context)
    {
        if (value < 0 || value > 10000)
            context.Error("概率必须在 0～10000 之间。", "PROBABILITY_RANGE");
    }
}
