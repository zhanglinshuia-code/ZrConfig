namespace Tutorial.Config
{
    public sealed class BattleSettings
    {
        public int MaxTargets = 1;
        public bool Interruptible = true;
    }
}
