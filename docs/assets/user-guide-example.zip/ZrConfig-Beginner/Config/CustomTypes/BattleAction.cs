using ZrConfig.Runtime;

namespace Tutorial.Config
{
    public abstract class BattleAction
    {
        public float Delay;
    }

    public sealed class Damage : BattleAction
    {
        public float Ratio = 1;
        public bool CanCrit;
    }

    public sealed class AddBuff : BattleAction
    {
        [ConfigRequired]
        public int BuffId;

        public int Stacks = 1;
    }
}
